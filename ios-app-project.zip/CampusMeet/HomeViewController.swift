﻿import UIKit
import JitsiMeetSDK

final class HomeViewController: UIViewController {

    // MARK: - UI

    private let titleLabel = UILabel()
    private let serverField = UITextField()
    private let roomField = UITextField()
    private let joinButton = UIButton(type: .system)
    private let hintLabel = UILabel()

    private var jitsiView: JitsiMeetView?

    private let defaults = UserDefaults.standard
    private let serverKey = "serverURL"

    // MARK: - Lifecycle

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemGroupedBackground
        setupUI()
    }

    // MARK: - UI Setup

    private func setupUI() {
        titleLabel.text = "北城测试"
        titleLabel.font = .boldSystemFont(ofSize: 28)
        titleLabel.textAlignment = .center

        serverField.placeholder = "服务器地址，例如 https://192.168.2.23:8443"
        serverField.text = defaults.string(forKey: serverKey) ?? "https://192.168.2.23:8443"
        serverField.borderStyle = .roundedRect
        serverField.autocorrectionType = .no
        serverField.autocapitalizationType = .none
        serverField.keyboardType = .URL

        roomField.placeholder = "会议名称（建议英文字母或数字）"
        roomField.borderStyle = .roundedRect
        roomField.autocorrectionType = .no
        roomField.autocapitalizationType = .none

        joinButton.setTitle("加入会议", for: .normal)
        joinButton.titleLabel?.font = .boldSystemFont(ofSize: 18)
        joinButton.backgroundColor = .systemBlue
        joinButton.setTitleColor(.white, for: .normal)
        joinButton.layer.cornerRadius = 10
        joinButton.addTarget(self, action: #selector(joinTapped), for: .touchUpInside)

        hintLabel.text = "提示：入会后点「更多」→「共享屏幕」即可共享手机屏幕"
        hintLabel.font = .systemFont(ofSize: 13)
        hintLabel.textColor = .secondaryLabel
        hintLabel.textAlignment = .center
        hintLabel.numberOfLines = 0

        let stack = UIStackView(arrangedSubviews: [titleLabel, serverField, roomField, joinButton, hintLabel])
        stack.axis = .vertical
        stack.spacing = 16
        stack.setCustomSpacing(28, after: titleLabel)
        stack.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(stack)

        NSLayoutConstraint.activate([
            stack.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: -40),
            stack.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 28),
            stack.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -28),
            serverField.heightAnchor.constraint(equalToConstant: 44),
            roomField.heightAnchor.constraint(equalToConstant: 44),
            joinButton.heightAnchor.constraint(equalToConstant: 48)
        ])

        let tap = UITapGestureRecognizer(target: view, action: #selector(UIView.endEditing(_:)))
        view.addGestureRecognizer(tap)
    }

    // MARK: - Actions

    @objc private func joinTapped() {
        view.endEditing(true)

        let serverText = (serverField.text ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        let room = (roomField.text ?? "").trimmingCharacters(in: .whitespacesAndNewlines)

        guard !room.isEmpty else {
            showAlert("请先输入会议名称")
            return
        }
        guard let serverURL = URL(string: serverText), serverURL.scheme == "https", serverURL.host != nil else {
            showAlert("服务器地址不正确，应以 https:// 开头")
            return
        }

        defaults.set(serverText, forKey: serverKey)

        let options = JitsiMeetConferenceOptions.fromBuilder { builder in
            builder.serverURL = serverURL
            builder.room = room
            // 开启 iOS 屏幕共享（配合 BroadcastExtension 使用）
            builder.setFeatureFlag("ios.screensharing.enabled", withBoolean: true)
            builder.setAudioMuted(false)
            builder.setVideoMuted(false)
        }

        let meetView = JitsiMeetView(frame: view.bounds)
        meetView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        meetView.delegate = self
        meetView.join(options)
        jitsiView = meetView
        view.addSubview(meetView)
    }

    private func showAlert(_ message: String) {
        let alert = UIAlertController(title: "提示", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "好的", style: .default))
        present(alert, animated: true)
    }
}

// MARK: - JitsiMeetViewDelegate

extension HomeViewController: JitsiMeetViewDelegate {

    func conferenceTerminated(_ data: [AnyHashable: Any]!) {
        DispatchQueue.main.async {
            self.jitsiView?.removeFromSuperview()
            self.jitsiView = nil
        }
    }
}
